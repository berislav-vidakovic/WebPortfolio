// view.js
import { GAME_LEVELS } from "./constants.js";
class View {
  constructor() {
      this.gameLevels = GAME_LEVELS;
      this.inputElement = document.getElementById("inputContent"); // Reference to input element
  }
  // Function to update the input element with the message
  renderContent(message) {
      this.inputElement.value = message;
  }
  // Init function to set the initial content of inputContent
  init() {
    this.inputElement.value = "";
  }
}
export default View;
