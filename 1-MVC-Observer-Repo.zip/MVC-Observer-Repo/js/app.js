// app.js
import Model from './model.js';
import View from './view.js';
import Controller from './controller.js';

import Repository from "./repository.js";
import FirestoreDatabase from "./database/FirestoreDB.js";

// Use Firestore as the database
const database = new FirestoreDatabase();
const repository = new Repository(database);
const model = new Model(repository);
const view = new View();
// Inject the instances into Controller
const controller = new Controller(model, view); // App entry point