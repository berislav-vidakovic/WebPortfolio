// repository.js
class Repository { 
  constructor(database) {
      this.database = database; // Injected FirestoreDatabase
  }

  async readDBkey(coll, doc, key) {
      return this.database.read(coll, doc, key);
  }

  async updateDB(coll, doc, key, value) {
      return this.database.update(coll, doc, key, value);
  }

  subscribeCollection(coll, callback) {
    this.database.subscribeCollection(coll, callback);
  }
}

export default Repository;
