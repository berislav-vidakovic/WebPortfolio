// model.js
import { GAME_LEVELS } from "./constants.js";

class Model {
  constructor(repository) {
    this.data = "";  // Placeholder for storing data
    this.gameLevels = GAME_LEVELS;
    this.repository = repository;
    this.observers = [];  // Array to hold observers (the Controller)
  }
  // Init function to set initial data to "Welcome!"
  init() {
    this.data = "Welcome back!"; // Initialize the data with "Welcome!"
    // Subscribe to the Firestore collection 'Dummy' and listen for changes
    this.repository.subscribeCollection("Dummy", this.handleChanges.bind(this)); // Pass handleChanges as the callback f.
  }
  // Function to handle changes from Firestore and update the model's data
  handleChanges(newValue) {
    const doc = newValue.find(el=>el.hasOwnProperty('DummyDoc'));        
    this.data = doc['DummyDoc'].DummyMsg; // Update the model's data with the new value
    console.log("DB:", this.data); // Log the updated value to the console
    this.notifyObservers(); // Notify all observers (controller) about the data change
  }
  // Function to add an observer (Controller)
  addObserver(observer) {
    this.observers.push(observer);
  }
  // Function to notify all observers that data has changed
  notifyObservers() {
    this.observers.forEach(observer => observer.onModelUpdated(this.data));
  }
  // Function to fetch message from Firestore
  async fetchMessage() {
    const message = await this.repository.readDBkey("Dummy", "DummyDoc", "DummyMsg");
    this.data = message;
  }
  // Function to update the data in Firestore
  async updateDataToDB(value) {
    await this.repository.updateDB("Dummy", "DummyDoc", "DummyMsg", value); // Update the value in DB
  }
}
export default Model;