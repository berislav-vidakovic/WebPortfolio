//constants.js
export const GAME_LEVELS = 6;