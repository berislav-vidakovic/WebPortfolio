// dbFirestoreNoSQL.js
// Import Firebase and Firestore functions
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { getFirestore, doc, updateDoc, getDoc, onSnapshot, collection } 
  from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

/* ----CLIENT USAGE -----------------------------------------------------------
  Firestore DB (NoSQL, Document-based) provides BaaS for serverless Front-End 
  App to implement data persistency and automatic browser refresh in real-time

-------FIRESTORE DB SETTINGS --------------------------------------------------
 -update firebaseConfig object (defined in this file below) with required 
    values from Firestore (Project->Settings->Web App)
 -update Rules on Firestore DB (Firestore DB->Rules) for read/write permissions
    rules_version = '2';
    service cloud.firestore {
      match /databases/{database}/documents {
        match /{document=**} {
          // Allow read and write for testing purposes
          allow read, write: if true;
        }
      }
    }
 
------APP MODEL IMPLEMENTATION ---------------------------------------------------
1-import dependencies
    import { subscribeCollection, readDBkey, updateDB } from './dbFirestoreNoSQL.js';
2-subscribe to Firestore collection for real-time refresh
    subscribeCollection('collectionName', handleCollectionChanges);
3-implement handling callback function, receives JS object
    function handleCollectionChanges(objectChanges) { }
4-read from DB
    const value = await readDBkey( 'collectionName', 'document', 'key' );
5-update DB
    await updateDB( 'collectionName', 'document', 'key', 'value' );     */

// firebaseConfig object - update with required values from Firestore
const firebaseConfig = {
    apiKey: "AIzaSyCBSwWx50dibvQQcGd2-ZtWiAghCi1EMI0",
    authDomain: "mastermindbv75.firebaseapp.com",
    projectId: "mastermindbv75",
    storageBucket: "mastermindbv75.firebasestorage.app",
    messagingSenderId: "245901977986",
    appId: "1:245901977986:web:d7716512d026ff10fc479b"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
// Get Firestore instance
const db = getFirestore(app);

// Listen to updates in collection
let unsubscribe = null; // Store the unsubscribe function
// Reference to the listening collection
let collectionListening = null;
subscribeCollection("initCollection", handleCollectionUpdate);

export function subscribeCollection(collectionName, callbackFunction)
{
    // First, unsubscribe from the previous listener (if any)
    if (unsubscribe) 
        unsubscribe();  // Stops listening to the previous item
    collectionListening = collection(db, collectionName);
    // Listen for real-time updates in the passed collection
    unsubscribe = onSnapshot(collectionListening, (querySnapshot) => {
        const docsToUpdate = [];
        querySnapshot.forEach((docSnap) => {
            docsToUpdate.push({ [docSnap.id]: docSnap.data() });
        });
        callbackFunction(docsToUpdate);
    });
}

function handleCollectionUpdate(changes) 
{
    console.log("Fresh Data", changes);
}

/*
// Listen to real-time updates on the document
    
// Reference to a specific document in the "sharedData" collection
let userRef = doc(db, "mastermind", "CurrentGame");

onSnapshot(userRef, (docSnap) => {
    if (docSnap.exists()) {
        // Get the updated data from Firestore
        console.log("Current data (from onSnapshot): ", docSnap.data());
        // You can update your UI here based on the changes
        document.getElementById("output").innerText = "Codemaker: " + docSnap.data().codemaker;
        document.getElementById("output").innerText += "\nCodebreaker: " + docSnap.data().codebreaker;

    } else {
        console.log("No such document!");
    }
});
*/

//
/* SUB-COLLECTION
import { collection, onSnapshot, doc } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

// Reference to a subcollection of "orders" for a specific user (user1)
const ordersRef = collection(doc(db, "users", "user1"), "orders");

// Listen for real-time updates in the "orders" subcollection
onSnapshot(ordersRef, (querySnapshot) => {
    querySnapshot.forEach((docSnap) => {
        console.log(docSnap.id, " => ", docSnap.data());
        // You can update your UI here with the updated order data
    });
}); */

/* FILTER 
import { collection, query, where, onSnapshot } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js';

// Reference to the "users" collection, but filter only active users
const usersRef = collection(db, "users");
const q = query(usersRef, where("status", "==", "active"));

// Listen to real-time updates of active users only
onSnapshot(q, (querySnapshot) => {
    querySnapshot.forEach((docSnap) => {
        console.log(docSnap.id, " => ", docSnap.data());
        // Update your UI with the active user data
    });
});  */

// Interface functions to be used from Model
export async function readDBkey( collection, documentDB, key )
{
    const docRef = doc(db, collection, documentDB);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
        return docSnap.data()[key];
    } else {
        return null;
    }
} 

export async function updateDB( collection, documentDB, key, value )
{
    try {
        await updateDoc(doc(db, collection, documentDB), { 
            [key]: value
        });
    } catch (error) {
        console.error("❌ Error saving data:", error);
    }
}
/*
export async function addDocumentToDB( collectionName, documentID )
{
    try {
      const docRef = doc(collection(db, collectionName), documentID); // Create doc reference
      await setDoc(docRef, { 
        // Your document data goes here
        //field1: "value1",
        //field2: "value2"
    });
    console.log(`Document ${documentID} added!`);
        
        //console.log("✅ Data saved successfully!");
        //document.getElementById("output").innerText = "Data saved!";
    } catch (error) {
        console.error("❌ Error addind document:", error);
    }
}*/