// model.js - Model class to handle business logic
class Model {
  handleGET(params) {
    // params = URL.searchParams
    let extractedParam = '';
    if(params)
      extractedParam = params.get('Id'); // Extracted value

    const res = extractedParam ? `GET with Id=${extractedParam} received` : 'GET clear I received!'; 
    console.log(res);
    return res;
  }

  handlePOST(data) {
    const res = `POST: ${data}-received!`;
    console.log(res);
    return res;
  }

}

export default Model;

