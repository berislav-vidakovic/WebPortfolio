// app.js - App class to initialize and start the server
import http from 'http';
import ControllerBackend from './controllerBackend.js';
import Model from './model.js';

class App {
  constructor() {
    this.model = new Model(); // Create the Model instance
    this.controller = new ControllerBackend(this.model); // Inject Model into Controller
    this.server = http.createServer((req, res) => this.handleRequest(req, res));
  }

  // Start the server
  start(port = 3000) {
    this.server.listen(port, () => {
        console.log(`Server running on port ${port}`);
    });
  }

  // Global request handler (calls controller)
  handleRequest(req, res) {
    // Apply CORS before calling the controller
    if (this.handleCORS(req, res)) 
      return;
    // Delegate request to controller
    this.controller.handleRequest(req, res);
  }

  // CORS Middleware
  handleCORS(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*'); // Allow all origins
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    // Handle preflight request
    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return true; // Stop further execution
    }
    return false;
  }
}

export default  App;