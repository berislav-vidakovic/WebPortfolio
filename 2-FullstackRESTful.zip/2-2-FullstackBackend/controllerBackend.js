// controllerBackend.js - ControllerBackend class to handle incoming requests
class ControllerBackend {
  constructor(model) {
    this.model = model; // Inject the Model instance
  }

  // Method to handle HTTP requests
  handleRequest(req, res) {
    let data = '';
    req.on('data', chunk => { data += chunk; console.log(chunk); });

    req.on('end', () => {
      console.log(req.url);
      if (req.method === 'GET' && req.url.startsWith('/apiEndpoint')) {
        const url = new URL(req.url, `http://${req.headers.host}`);
        const response = this.model.handleGET(url.searchParams);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ Backend: response }));
        // Since GET requests do not have a body, immediately trigger 'end'
        // req.emit('end');
      }
      else if (req.method === 'POST' && req.url === '/apiEndpoint') {
        // Business logic handled by Model
        const response = this.model.handlePOST(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ Backend: response }));
      }
      else {
        // Handle other routes
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Route Not Found' }));
      }
    });
  }
}

export default ControllerBackend;