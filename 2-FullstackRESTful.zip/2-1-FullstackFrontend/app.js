const serverURL = 'http://localhost:3000';
const endpoint = '/apiEndpoint';

class FrontendApp {
  constructor(){
    this.url = serverURL + endpoint;
    console.log('ctor');
  }
  run() {
    document.getElementById("btnGET").addEventListener("click", this.handleGet.bind(this));    
    document.getElementById("btnGETp").addEventListener("click", this.handleGetP.bind(this));    
    console.log('run');
    document.getElementById("btnPOST").addEventListener("click", this.handlePost.bind(this));    
    document.getElementById("output").textContent = 'Output';
    document.getElementById("inputContent").value = 'input';
  }

  fetchAndHandle(url, requestContent)
  {
    fetch(url, requestContent) 
      .then(response => response.json()) // Convert the response to JSON
      .then(data => {
        document.getElementById("output").textContent = JSON.stringify(data);
        console.log(data);
      })
      .catch(error => {
        console.error('Error:', error); // Handle any errors
      });
  }
  
  handleGet() {
    this.fetchAndHandle(`${serverURL}${endpoint}`, { method: 'GET' });
  }

  handleGetP(){
    const Id = document.getElementById("inputContent").value 
    this.fetchAndHandle(`${serverURL}${endpoint}?Id=${Id}`, { method: 'GET' });
  }

  handlePost(){
    const Id = document.getElementById("inputContent").value 
    this.fetchAndHandle(`${serverURL}${endpoint}`, {
      method: 'POST', // Specify that it's a POST request
      headers: { 'Content-Type': 'application/json' }, // Tell the server we're sending JSON data
      body: JSON.stringify({ Id: Id })}); // Convert the JavaScript object to a JSON string
  }
}

const app = new FrontendApp();
app.run();