// database/IDatabase.js
class IDatabase {
  async read(coll, doc, key) {
      throw new Error("read() must be implemented");
  }

  async update(coll, doc, key, value) {
      throw new Error("update() must be implemented");
  }

  subscribeCollection(coll, callback) {
    throw new Error("subscribeCollection() must be implemented");
  }
}

export default IDatabase;
