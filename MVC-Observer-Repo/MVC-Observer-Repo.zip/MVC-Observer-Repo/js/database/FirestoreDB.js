// database/FirestoreDatabase.js
import IDatabase from "./IDatabase.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.11.1/firebase-app.js";
import { getFirestore, collection, getDoc, updateDoc, onSnapshot, doc } 
  from "https://www.gstatic.com/firebasejs/10.11.1/firebase-firestore.js";

// Firebase config (moved inside class)
const firebaseConfig = {
  apiKey: "AIzaSyCBSwWx50dibvQQcGd2-ZtWiAghCi1EMI0",
  authDomain: "mastermindbv75.firebaseapp.com",
  projectId: "mastermindbv75",
  storageBucket: "mastermindbv75.firebasestorage.app",
  messagingSenderId: "245901977986",
  appId: "1:245901977986:web:d7716512d026ff10fc479b"
};

class FirestoreDatabase extends IDatabase {
    constructor() {
        super();
        // Initialize Firebase inside the class
        this.app = initializeApp(firebaseConfig);
        this.db = getFirestore(this.app); // Firestore instance
        this.unsubscribe = null; // Store unsubscribe function
    }

    async read(coll, docId, key) {
        const docRef = doc(this.db, coll, docId);
        const snapshot = await getDoc(docRef);
        return snapshot.exists() ? snapshot.data()[key] : null;
    }

    async update(coll, docId, key, value) {
        const docRef = doc(this.db, coll, docId);
        await updateDoc(docRef, { [key]: value });
        return { key, value };
    }

    subscribeCollection(coll, callback) {
      // First, unsubscribe from the previous listener (if any)
      if (this.unsubscribe) this.unsubscribe();

      const collectionRef = collection(this.db, coll);
      this.unsubscribe = onSnapshot(collectionRef, (querySnapshot) => {
          const docsToUpdate = [];
          querySnapshot.forEach((docSnap) => {
              docsToUpdate.push({ [docSnap.id]: docSnap.data() });
          });
          callback(docsToUpdate);
      });
    }
}

export default FirestoreDatabase;
