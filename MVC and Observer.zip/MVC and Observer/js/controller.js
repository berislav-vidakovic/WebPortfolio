// controller.js
class Controller {
  constructor(model, view) {
    this.model = model;
    this.view = view;
    // Initialize the app (sets initial content in inputContent)
    this.model.init();
    this.view.init();
    // Register the controller as the observer of the model
    this.model.addObserver(this);  // Controller is the observer now
    // Pass the model data to the view to render
    this.view.renderContent(this.model.data);
    // Bind buttons to click event
    document.getElementById("btnRead").addEventListener("click", this.handleReadClick.bind(this));
    document.getElementById("btnWrite").addEventListener("click", this.handleWriteClick.bind(this));    
  }
  // Handle the click event for the Read button
  async handleReadClick() {
    await this.model.fetchMessage(); // Fetch message from Firestore
    this.view.renderContent(this.model.data); // Update the view with the message
  }
  // Handle the click event for the Write button
  async handleWriteClick() {
    const valueToWrite = document.getElementById("inputContent").value; // Get the current value 
    await this.model.updateDataToDB(valueToWrite); // Update the value in Firestore
  }
  // Function to update the view (called when model data changes)
  onModelUpdated(message) {
    this.view.renderContent(message); // Pass the updated message to the view
  }
}
export default Controller;
